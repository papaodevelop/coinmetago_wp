export const CUSTOMER = "customer";
